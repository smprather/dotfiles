# gnome-screenshot

> Capture the screen, a window, or a user-defined area and save the image to a file.
> More information: <https://manned.org/gnome-screenshot>.

- Take a screenshot and save it to the default location, normally `~/Pictures`:

`gnome-screenshot`

- Take a screenshot and save it to the named file location:

`gnome-screenshot {{[-f|--file]}} {{path/to/file}}`

- Take a screenshot and save it to the clipboard:

`gnome-screenshot {{[-c|--clipboard]}}`

- Take a screenshot after the specified number of seconds:

`gnome-screenshot {{[-d|--delay]}} {{5}}`

- Launch the GNOME Screenshot GUI:

`gnome-screenshot {{[-i|--interactive]}}`

- Take a screenshot of the current window and save it to the specified file location:

`gnome-screenshot {{[-w|--window]}} {{[-f|--file]}} {{path/to/file}}`

- Take a screenshot after the specified number of seconds and save it to the clipboard:

`gnome-screenshot {{[-d|--delay]}} {{10}} {{[-c|--clipboard]}}`

- Display version:

`gnome-screenshot --version`
