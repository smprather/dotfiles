# flameshot

> Screenshot utility with a GUI.
> Supports basic image editing, such as text, shapes, colors, and imgur.
> More information: <https://flameshot.org/docs/advanced/commandline-options/>.

- Create a fullscreen screenshot:

`flameshot full`

- Create a screenshot interactively:

`flameshot gui`

- Create a screenshot and save it to a specific path:

`flameshot gui {{[-p|--path]}} {{path/to/directory}}`

- Create a screenshot interactively in a simplified mode:

`flameshot launcher`

- Create a screenshot from a specific monitor:

`flameshot screen {{[-n|--number]}} {{2}}`

- Create a screenshot and print it to `stdout`:

`flameshot gui {{[-r|--raw]}}`

- Create a screenshot and copy it to the clipboard:

`flameshot gui {{[-c|--clipboard]}}`

- Create a screenshot with a specific delay in milliseconds:

`flameshot full {{[-d|--delay]}} {{5000}}`
