# goaccess

> An open source real-time web log analyzer.
> More information: <https://goaccess.io/man>.

- Analyze one or more log files in interactive mode:

`goaccess {{path/to/logfile1 path/to/file2 ...}}`

- Use a specific log-format (or pre-defined formats like "combined"):

`goaccess {{path/to/logfile}} --log-format={{format}}`

- Analyze a log from `stdin`:

`tail {{[-f|--follow]}} {{path/to/logfile}} | goaccess -`

- Analyze a log and write it to an HTML file in real-time:

`goaccess {{path/to/logfile}} {{[-o|--output]}} {{path/to/file.html}} --real-time-html`
