# xbps-install

> XBPS utility to (re)install and update packages.
> See also: `xbps`.
> More information: <https://manned.org/xbps-install>.

- Install a new package:

`xbps-install {{package}}`

- Synchronize and update all packages:

`xbps-install {{[-Su|--sync --update]}}`
